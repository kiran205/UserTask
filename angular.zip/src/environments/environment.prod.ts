export const environment = {
  production: true,
  postUrl: 'http://localhost:3000/posts',
};
